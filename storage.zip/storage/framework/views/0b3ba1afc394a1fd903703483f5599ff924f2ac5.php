Your Invoice:<?php echo e($sale_id); ?>

