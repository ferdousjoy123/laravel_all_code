<?php $__env->startSection('add-page'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
   <ol class="breadcrumb">
     <li><a href="<?php echo e(url('/home')); ?>">
       <em class="fa fa-home"></em>
     </a></li>
     <li><a href="<?php echo e(url('/add/product')); ?>">
       <em class="fa fa-home"></em>
     add product</a></li>
     <li class="active"><?php echo e($product->product_name); ?></li>
   </ol>
 </div><!--/.row-->

 <div class="row">
   <div class="col-lg-12">
     <h1 class="page-header">Dashboard</h1>
   </div>
<div class="container">

    <div class="row justify-content-center">

        <div class="col-md-6">
            <div class="card">
                <div class="card-head"><h2> Edit Products</h2></div>

                <div class="card-body">

                  <?php if(session('success')): ?>
                  <div class="alert alert-info">
<?php echo e(session('success')); ?>

                  </div>

                  <?php endif; ?>

                 <form action="/update/product" method="post">

<?php echo csrf_field(); ?>

 <div class="form-group">
   <label>Product name</label>
   <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
   <input type="text" class="form-control" name="product_name" placeholder="Product name" value="<?php echo e($product->product_name); ?>" >
   <?php if($errors->has('product_name')): ?>
          <strong style="color:red"><?php echo e($errors->first('product_name')); ?></strong>
   <?php endif; ?>
 </div>
 <div class="form-group">
   <label>Product price</label>
   <input type="text" class="form-control" name="product_price" placeholder="Product price" value="<?php echo e($product->product_price); ?>">
   <?php if($errors->has('product_price')): ?>

           <strong style="color:red" ><?php echo e($errors->first('product_price')); ?></strong>

   <?php endif; ?>
 </div>

 <button type="submit" class="btn btn-primary">edit Price</button>
</form><br>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>