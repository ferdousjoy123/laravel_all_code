<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">Your statistics</h1>
  </div>

  <div class="col-lg-6">
<h1>Total purchase</h1><br>
<?php echo e($total_sale); ?>

  </div>
  <div class="col-lg-6">
<h1>Total product</h1><br>
<?php echo e($total_products); ?>

  </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>