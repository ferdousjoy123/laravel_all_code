<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"> <h1> View All Product-<?php echo e(App\Product::count()); ?></h1></div>

                <div class="card-body">
                   <table class="table table-borders">
<thead>
<th>SL</th>
  <th>category name</th>
  <th>Product availity</th>
  <th>Product name</th>
  <th>Product Quantity</th>
  <th>alert Quantity</th>
  <th>product price</th>
  <th> Created_at</th>
  <th> photo</th>
  <th> Last updated</th>
  <th> Action</th>

</thead>
<?php
  $count=1;
?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
   <td><?php echo e($count++); ?></td>
  <td><?php echo e($product->get_category_name->category_name); ?></td>
  <td>
    <?php if($product->alert_quantity>=($product->product_quantity)): ?>
<span style="background:red; padding:10px; color:#fff;"> product is near to unavailable</span>
<?php else: ?>
<span style="background:green; padding:10px; color:#fff;">product avialable</span>
    <?php endif; ?>

  </td>
  <td><?php echo e($product->product_name); ?></td>
  <td><?php echo e($product->product_quantity); ?></td>
  <td><?php echo e($product->alert_quantity); ?></td>
  <td><?php echo e($product->product_price); ?></td>
  <td><?php echo e($product->created_at); ?></td>
  <td> <img  width="50" src="<?php echo e(asset('testing/'.$product->product_image)); ?>" >   </td>
  <td><?php echo e($product->updated_at ? $product->updated_at:"Not Yet"); ?></td>
  <td>
    <a href="<?php echo e(url('delete/product')); ?>/<?php echo e($product->id); ?>" class="btn btn-danger">Delete</a>-
    <a href="<?php echo e(url('edit/product')); ?>/<?php echo e($product->id); ?>" class="btn btn-info">Edit</a>

  </td>
  <td>--</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </table>
                    <?php echo e($products->links()); ?>

                </div>
                <?php if(session('successdelte')): ?>
                <div class="alert alert-info">
      <?php echo e(session('successdelte')); ?>

                </div>

                <?php endif; ?>

            </div>
        </div>
    </div>


<?php if($deleted_products->count() >0): ?>
  <div class="row justify-content-center">
      <div class="col-md-8">
          <div class="card">
              <div class="card-header"> <h1> View All Delected Product <?php echo e($deleted_products->count()); ?> </h1>

              </div>

              <div class="card-body">
                 <table class="table table-borders">
  <thead>

  <th>SL</th>
  <th>Product name</th>
  <th>product price</th>
  <th> Created_at</th>
  <th> Last updated</th>
  <th> Action</th>

  </thead>
  <?php
    $count=1;
  ?>
  <?php $__currentLoopData = $deleted_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted_products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
 <td><?php echo e($count++); ?></td>
  <td><?php echo e($deleted_products->product_name); ?></td>
  <td><?php echo e($deleted_products->product_price); ?></td>
  <td><?php echo e($deleted_products->created_at); ?></td>
  <td><?php echo e($deleted_products->updated_at ? $deleted_products->updated_at:"Not Yet"); ?></td>
  <td>
  <a href="<?php echo e(url('restore/product')); ?>/<?php echo e($deleted_products->id); ?>" class="btn btn-success">Restore</a>


  </td>
  <td>--</td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </table>
                  <?php echo e($products->links()); ?>

              </div>
              <?php if(session('successdelte')): ?>
              <div class="alert alert-info">
    <?php echo e(session('successdelte')); ?>

              </div>

              <?php endif; ?>

          </div>
      </div>
  </div>

<?php endif; ?>














</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>