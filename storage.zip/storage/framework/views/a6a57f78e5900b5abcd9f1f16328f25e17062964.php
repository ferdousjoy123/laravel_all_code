<?php $__env->startSection('add-banner-page'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
  <ol class="breadcrumb">
    <li><a href="#">
      <em class="fa fa-home"></em>
    </a></li>
    <li class="active">Dashboard</li>
  </ol>
</div>

<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">Dashboard</h1>
  </div>
  </div>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h2> Add Banner</h2></div>
                <div class="card-body">
                  <?php if(session('success')): ?>
                 <div class="alert alert-info">
<?php echo e(session('success')); ?>

                 </div>

                 <?php endif; ?>
   <form action="/banner/insert" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

 <div class="form-group">
   <label>heading</label>
   <input type="text" class="form-control" name="heading">
 </div>

 <div class="form-group">
   <label>sub_heading</label>
   <input type="text" class="form-control" name="sub_heading">
 </div>
 <div class="form-group">
   <label>details</label>
   <input type="text" class="form-control" name="details">
 </div>
 <div class="form-group">
   <label>banner_image</label>
   <input type="file" class="form-control" name="banner_image">
 </div>

 <button type="submit" class="btn btn-primary">Add banner</button>
</form>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>