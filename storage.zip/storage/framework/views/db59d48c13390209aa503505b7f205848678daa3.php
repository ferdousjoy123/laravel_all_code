<?php $__env->startSection('add-category-page'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
  <ol class="breadcrumb">
    <li><a href="#">
      <em class="fa fa-home"></em>
    </a></li>
    <li class="active">Dashboard</li>
  </ol>
</div><!--/.row-->

<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">Dashboard</h1>
  </div>
  </div>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h2> Add Category</h2></div>
                <div class="card-body">
                 <form action="/category/insert" method="post">
<?php echo csrf_field(); ?>

 <div class="form-group">
   <label>Category name</label>
   <input type="text" class="form-control" name="category_name" placeholder="Enter Category">

 </div>


 <button type="submit" class="btn btn-primary">Add category</button>
</form><br>


                </div>
            </div>
        </div>
        <div class="col-lg-6">

          <div class="card">
              <div class="card-header"> <h1> View All Category-<?php echo e(App\Category::count()); ?></h1></div>

              <div class="card-body">
                 <table class="table table-bordered">
<thead>

<th>SL</th>
<th>category name</th>
<th> Created_at</th>
<th> Last updated</th>
<th> Status</th>
<th> Action</th>

</thead>
<?php
  $count=1;
?>
<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($count++); ?></td>
<td><?php echo e($category->category_name); ?></td>

<td><?php echo e($category->created_at); ?></td>
<td><?php echo e($category->updated_at ? $category->updated_at:"Not Yet"); ?></td>
<td>
  <?php if( $category->status==1): ?>
  <span style="color:green; background-color:black; padding:5px;">Active</span>
<?php else: ?>
   <span style="color:red; background-color:black; padding:5px;">Deactive</span>
  <?php endif; ?>
</td>
<td>
   <a href="<?php echo e(url('change/status')); ?>/<?php echo e($category->id); ?>" class="btn btn-sm btn-info">Change Status</a>

</td>
<td>--</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </table>

              </div>


          </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>