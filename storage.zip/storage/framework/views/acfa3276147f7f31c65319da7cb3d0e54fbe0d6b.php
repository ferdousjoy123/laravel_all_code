<?php $__env->startSection('add-page'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
  <ol class="breadcrumb">
    <li><a href="#">
      <em class="fa fa-home"></em>
    </a></li>
    <li class="active">Dashboard</li>
  </ol>
</div><!--/.row-->

<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">Dashboard</h1>
  </div>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h2> Add Products</h2></div>

                <div class="card-body">

                  <?php if(session('success')): ?>
                  <div class="alert alert-info">
<?php echo e(session('success')); ?>

                  </div>

                  <?php endif; ?>

                 <form action="/product/insert" method="post" enctype="multipart/form-data">

<?php echo csrf_field(); ?>

 <div class="form-group">
   <label>category name</label>
<select class="form-control" name="category_id">
<option value="">--SELECT ONE--</option>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?> </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>
   <label>Product name</label>
   <input type="text" class="form-control" name="product_name" placeholder="Product name" value=<?php echo e(old('product_name')); ?>>
   <?php if($errors->has('product_name')): ?>
          <strong style="color:red"><?php echo e($errors->first('product_name')); ?></strong>
   <?php endif; ?>
 </div>
 <div class="form-group">
   <label>Product price</label>
   <input type="text" class="form-control" name="product_price" placeholder="Product price" value=<?php echo e(old('product_price')); ?>>
   <?php if($errors->has('product_price')): ?>
           <strong style="color:red" ><?php echo e($errors->first('product_price')); ?></strong>
   <?php endif; ?>
 </div>
 <div class="form-group">
   <label>Product Details</label>
  <textarea name="product_details" placeholder="Alert price" value=<?php echo e(old('product_details')); ?> rows="12" cols="80"></textarea>

   <?php if($errors->has('product_details')): ?>
           <strong style="color:red" ><?php echo e($errors->first('product_details')); ?></strong>
   <?php endif; ?>
 </div>
 <div class="form-group">
   <label>Product quantity</label>
   <input type="number" class="form-control" name="product_quantity" placeholder="Alert price" value=<?php echo e(old('product_quantity')); ?>>
   <?php if($errors->has('product_quantity')): ?>
           <strong style="color:red" ><?php echo e($errors->first('product_quantity')); ?></strong>
   <?php endif; ?>
 </div>


 <div class="form-group">
   <label>alert quantity</label>
   <input type="number" class="form-control" name="alert_quantity" placeholder="Alert price" value=<?php echo e(old('alert_quantity')); ?>>
   <?php if($errors->has('alert_quantity')): ?>
           <strong style="color:red" ><?php echo e($errors->first('alert_quantity')); ?></strong>
   <?php endif; ?>
 </div>

 <div class="form-group">
   <label>Product image</label>
   <input type="file" class="form-control" name="product_image">

 </div>




 <button type="submit" class="btn btn-primary">Add Price</button>
</form><br>
<a href="<?php echo e(url('all/msg')); ?>" class="btn btn-info"> View all Meesage</a>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>